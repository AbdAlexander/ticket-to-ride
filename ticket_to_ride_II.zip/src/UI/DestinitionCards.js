const DestinationCards = () => {
    return (
        <div>
            <h6><strong>Célkártyák paklija</strong></h6>
            <img src="https://static.thenounproject.com/png/219525-200.png" height="160" width="200" alt=""/>
        </div>
    )
}
export default DestinationCards;