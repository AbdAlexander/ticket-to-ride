import { ticketToRideData } from "../../Utilities/Data/ticket-to-ride-data";

const initalState = ticketToRideData;

const gamedataReducer = (state = initalState, action) => { 
    //let copyState = Object.assign({}, state);

    return state;
};

export default gamedataReducer;